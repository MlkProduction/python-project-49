def congratulations(right_answer, round_game, name):
    if right_answer == round_game:
        print(f'{'Congratulations,'} {name}!')