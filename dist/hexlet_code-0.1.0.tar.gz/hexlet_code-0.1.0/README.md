### Hexlet tests and linter status:
[![Actions Status](https://github.com/MlkProduction/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/MlkProduction/python-project-49/actions)
<a href="https://codeclimate.com/github/MlkProduction/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/e2dfd2f4c01f3673c4b8/maintainability" /></a>

### Asciinema :
[![asciicast](https://asciinema.org/a/EJ0iByaOfX7BmHRmLL9Km7CeU.svg)](https://asciinema.org/a/EJ0iByaOfX7BmHRmLL9Km7CeU)
